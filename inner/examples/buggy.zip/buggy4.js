function somethingElse() {
    if (5 > 2) {
        console.log("Больше");
    if (5 < 2) {
        console.log("Меньше");
    }
}

function gogogo() {
    console.log("Ура, заработало!");
}
