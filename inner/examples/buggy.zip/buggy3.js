function gogogo(); {
    Console.log("Ура, заработало!'');
)
