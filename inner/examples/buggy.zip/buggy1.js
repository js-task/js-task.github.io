function gogogo() {
    console.log("Ура, заработало!");
}
